/*2. Print the fields/instance members of the parent class using super
 * 5. Call constructor of the parent class using super() */
package CallUsingSuper;

public class Test {
    public static void main(String[] args) {
        Child obj = new Child();
        obj.display(); // Printing instance members of the parent class
    }
}