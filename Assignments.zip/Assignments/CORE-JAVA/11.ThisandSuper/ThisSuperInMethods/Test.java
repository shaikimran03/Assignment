/* 6. Use this() and super() in methods not in constructor */

package ThisSuperInMethods;

public class Test {
     public static void main(String[] args) {
        Child c = new Child();
        c.show();
    }
}
