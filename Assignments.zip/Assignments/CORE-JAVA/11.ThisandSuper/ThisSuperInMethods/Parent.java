/* 6. Use this() and super() in methods not in constructor */

package ThisSuperInMethods;

public class Parent {
    int number = 30;

    void display() {
        System.out.println("Parent class display method");
    }

}
