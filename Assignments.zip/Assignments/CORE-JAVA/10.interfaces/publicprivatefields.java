
 /* * 10. Create an interface with private, public and protected fields */   
interface publicprivatefields {
    int x = 10;               // same as: public static final int x = 10;
    // private int y = 20;    ❌ Not allowed
    // protected int z = 30;  ❌ Not allowed
}

