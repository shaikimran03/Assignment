package InterfacePublicfield;
public class Test {
      public static void main(String[] args) {
        MyClass obj = new MyClass();
        obj.displayInfo();
    }

}
