/*7. Create an interface and inherit it from the other interface. 
 */
package InheritInterface;

public interface Parent {

        void makeSound();

}
