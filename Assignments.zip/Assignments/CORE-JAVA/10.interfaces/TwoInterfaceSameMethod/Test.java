package TwoInterfaceSameMethod;

public class Test {
     public static void main(String[] args) {
        Myclass obj = new Myclass();
        obj.show(); // Calls the implemented method
    }

}
