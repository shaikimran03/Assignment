/*
 * 05. Create two interfaces with the same method (same signature) in both the interfaces.
 * Implement these two interfaces in one class. Call the method. */
package TwoInterfaceSameMethod;

public interface Interfaceone {

    void show();
} 
