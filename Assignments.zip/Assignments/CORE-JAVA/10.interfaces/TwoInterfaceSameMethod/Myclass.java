package TwoInterfaceSameMethod;

class Myclass {

     public void show() {
        System.out.println("Single implementation of show() method.");
    }

}