package TwoInterfaceSameMethod;

public interface Interfacetwo {
    void show();
}
