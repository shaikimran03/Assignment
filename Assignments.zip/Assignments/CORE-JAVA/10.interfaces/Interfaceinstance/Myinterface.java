package Interfaceinstance;

public interface Myinterface {
    void display();
}
