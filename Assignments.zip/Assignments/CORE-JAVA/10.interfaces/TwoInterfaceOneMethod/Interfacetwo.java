package TwoInterfaceOneMethod;

public interface Interfacetwo {
     void methodTwo();

}
