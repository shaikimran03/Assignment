package TwoInterfaceOneMethod;

public class Test {
     public static void main(String[] args) {
        Myclass obj = new Myclass();
        obj.methodOne(); // Calling method from InterfaceOne
        obj.methodTwo(); // Calling method from InterfaceTwo
    }

}
