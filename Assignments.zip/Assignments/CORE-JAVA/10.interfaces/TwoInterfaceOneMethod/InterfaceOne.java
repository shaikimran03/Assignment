/* 04.Create two interfaces with one method each. Implement these two interfaces in one
 * class. */
package TwoInterfaceOneMethod;

public interface InterfaceOne {

    void methodOne();

}
