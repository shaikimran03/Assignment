package InterfaceTwoMethods;

public class Test {
    public static void main(String[] args) {
        MyClass obj = new MyClass(); // Object creation
        obj.methodOne();
    }
}