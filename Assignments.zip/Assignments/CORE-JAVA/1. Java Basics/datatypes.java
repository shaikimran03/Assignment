public class datatypes {
     public static void main(String[] args) {
        // Defining variables of different data types
        int age = 21;
        boolean isStudent = true;
        char grade = 'B';
        float height = 6.1f;     // 'f' is required for float literals
        double weight = 62.75;

        // Printing the variables to the console
        System.out.println("Age (int): " + age);
        System.out.println("Is Student (boolean): " + isStudent);
        System.out.println("Grade (char): " + grade);
        System.out.println("Height (float): " + height);
        System.out.println("Weight (double): " + weight);
    }
    
}
