public class callingfunction {

    // Static method to print your name
    public static void printName() {
        System.out.println("Imran");  
    }

    public static void main(String[] args) {
        // Directly calling the static method without creating an object
        printName();
    }
}
