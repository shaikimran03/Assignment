public class Printingnumbers {
   public static void main(String[] args) {
        int number = 1;

        System.out.println("Numbers from 1 to 20:");

        while (number <= 20) {
            System.out.println(number);
            number++;
        }
    }
}


