public class DefaultClassFields {
       String message = "Hello from Default Field";
    
    // Default method
    void showMessage() {
        System.out.println("Hello from Default Method");
    }
}
