
// Function to update range value display
function updateRangeValue(value) {
    document.getElementById("rangeValue").textContent = value;
}
