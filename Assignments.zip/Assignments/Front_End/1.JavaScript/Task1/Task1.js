//1. Write a program which consist of single line and multiline comments. 

// This is a single-line comment
// Declaring two numbers
let a = 10;
let b = 5;

/*
 This is a multi-line comment.
 The following block adds two numbers
 and displays the result in the console.
*/

let sum = a + b; // Performing addition

// Display the result in the console
console.log("The sum of a and b is: " + sum);
// The following block subtracts two numbers